exports.userMenu = function() {
  return {
    controller: 'UserMenuController',
    templateUrl: '/8-examples/templates/user_menu.html'
  };
};
