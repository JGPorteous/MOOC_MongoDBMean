exports.userMenu = function() {
  return {
    controller: 'UserMenuController',
    templateUrl: '/9-examples/templates/user_menu.html'
  };
};

exports.productDetails = function() {
  return {
    controller: 'ProductDetailsController',
    templateUrl: '/9-examples/templates/product_details.html'
  };
};
