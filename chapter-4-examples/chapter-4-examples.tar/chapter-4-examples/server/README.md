This directory contains the server code necessary to run the examples from
Chapter 4. To run:

1. Copy your completed `config.json` from the Chapter 3 homework assignment into the `server` directory.
2. Run `npm install`
3. Run `node index.js`
4. Open `http://localhost:3000/B-examples/index.html` or whichever example you prefer in your browser
