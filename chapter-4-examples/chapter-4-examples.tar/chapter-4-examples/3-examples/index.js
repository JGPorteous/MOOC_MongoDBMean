window.alert(require('./sample'));
