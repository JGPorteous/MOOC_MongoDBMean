module.exports = 'Hello, world';
